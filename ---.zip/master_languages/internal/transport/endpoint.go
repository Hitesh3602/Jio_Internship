package http

import (
	"context"

	"github.com/Hitesh3602/master_languages/internal/model"
	"github.com/Hitesh3602/master_languages/internal/service"
	"github.com/go-kit/kit/endpoint"
)

type createLanguageRequest struct {
	Language model.Language
}

type getLanguagesResponse struct {
	Languages []*model.Language `json:"languages"`
}

func makeCreateLanguageEndpoint(svc service.LanguageService) endpoint.Endpoint {
	return func(ctx context.Context, request interface{}) (interface{}, error) {
		req := request.(createLanguageRequest)
		err := svc.CreateLanguage(&req.Language)
		if err != nil {
			return nil, err
		}
		return req.Language, nil
	}
}

func makeGetLanguagesEndpoint(svc service.LanguageService) endpoint.Endpoint {
	return func(ctx context.Context, request interface{}) (interface{}, error) {
		languages, err := svc.GetLanguages()
		if err != nil {
			return nil, err
		}
		return getLanguagesResponse{Languages: languages}, nil
	}
}

// Similarly define endpoints for GetLanguageByID, UpdateLanguage, and DeleteLanguage
