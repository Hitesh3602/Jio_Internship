package http

import (
	"context"
	"encoding/json"
	"net/http"

	"github.com/Hitesh3602/master_languages/internal/service"
	httptransport "github.com/go-kit/kit/transport/http"
	"github.com/gorilla/mux"
)

func NewHTTPHandler(svc service.LanguageService) http.Handler {
	router := mux.NewRouter()

	router.Methods("POST").Path("/rms/master_languages").Handler(httptransport.NewServer(
		makeCreateLanguageEndpoint(svc),
		decodeCreateLanguageRequest,
		encodeResponse,
	))

	router.Methods("GET").Path("/rms/master_languages").Handler(httptransport.NewServer(
		makeGetLanguagesEndpoint(svc),
		decodeEmptyRequest,
		encodeResponse,
	))

	// Similarly set up routes for GetLanguageByID, UpdateLanguage, and DeleteLanguage

	return router
}

func decodeCreateLanguageRequest(_ context.Context, r *http.Request) (interface{}, error) {
	var req createLanguageRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		return nil, err
	}
	return req, nil
}

func decodeEmptyRequest(_ context.Context, r *http.Request) (interface{}, error) {
	return nil, nil
}

func encodeResponse(_ context.Context, w http.ResponseWriter, response interface{}) error {
	return json.NewEncoder(w).Encode(response)
}
